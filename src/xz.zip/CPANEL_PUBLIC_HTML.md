# Despliegue en cPanel public_html

Sube el contenido de esta carpeta `src` dentro de la carpeta raiz de tu dominio.
En este hosting puede ser `public_html` o una carpeta con el nombre del dominio,
por ejemplo `itseportafolio.xyz`.

En cPanel, crea o configura la aplicacion de Python asi:

- Application root: `public_html` o `itseportafolio.xyz`, segun la carpeta real del dominio
- Application URL: `/`
- Application startup file: `passenger_wsgi.py`
- Application Entry point: `application`
- Python version: 3.6 o superior, recomendado 3.10 o superior

No uses Python 2.7. La aplicacion no puede ejecutarse con Python 2.

Si cPanel no crea el archivo `.htaccess` automaticamente, usa `cpanel.htaccess.example`
como base y reemplaza las rutas `TU_USUARIO` y `VERSION_PYTHON` por las que indique tu
panel.

Credenciales por defecto:

- Usuario: `admin`
- Contrasena: `1234`

Para cambiar las credenciales sin editar codigo, define estas variables de entorno en cPanel:

- `PORTAFOLIO_USUARIO`
- `PORTAFOLIO_PASSWORD`
- `PORTAFOLIO_SECRET`

La aplicacion guarda las fotos en `uploads/` y el registro en `data/photos.json`, asi que esas carpetas deben tener permiso de escritura para la aplicacion.
